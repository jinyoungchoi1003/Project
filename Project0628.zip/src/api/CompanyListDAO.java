package api;

import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class CompanyListDAO {
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String user = "c##green";
	String password = "green1234";

	private Connection con;
	private Statement stmt;
	private ResultSet rs;

	public boolean CompanyList(CompanyListVo c) {
		try {
			connDB();

			String query = "insert into companylist(kategorie,company,mainmenu,telNumber,ctprvnnm,signgunm,address)values('"
					+ c.getKategorie() + "','" + c.getCompany() + "','" + c.getMainMemu() + "','" + c.getTelNumber()
					+ "','" + c.getCtprvnNm() + "','" + c.getSignguNm() + "','" + c.getAddress() + "')";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);
			System.out.println("rs.getRow() : " + rs.getRow());

			if (rs.getRow() == 0) {
				System.out.println("0 row selected...");
			} else {
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

//	public ArrayList<String> KoreanFoodList(String list) {
//		ArrayList<String> values = new ArrayList<String>();
//		try {
//			connDB();
//
//			String query = "SELECT * FROM companylist WHERE KATEGORIE LIKE" + list;
//			System.out.println("SQL : " + query);
//			rs = stmt.executeQuery(query);
//
//			while (rs.next()) {
//				values.add(rs.getString(1));
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return values;
//	}

	public ArrayList<String> CompanyList(String info) {
		ArrayList<String> values = new ArrayList<String>();
		try {
			connDB();

			String query = "SELECT * FROM companylist";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				values.add(rs.getString(2));
//				System.out.println(rs.getString(2));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return values;
	}
	
	public ArrayList<String> KoreanList(String info) {
		ArrayList<String> values = new ArrayList<String>();
		try {
			connDB();

			String query = "SELECT company FROM companylist WHERE KATEGORIE LIKE '%한식%'";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				values.add(rs.getString(1));
//				System.out.println(rs.getString(1));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return values;
	}
	
	public ArrayList<String> ChineseList(String info) {
		ArrayList<String> values = new ArrayList<String>();
		try {
			connDB();

			String query = "SELECT company FROM companylist WHERE KATEGORIE LIKE '%중식%'";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				values.add(rs.getString(1));
//				System.out.println(rs.getString(1));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return values;
	}
	
	public ArrayList<String> JapaneseList(String info) {
		ArrayList<String> values = new ArrayList<String>();
		try {
			connDB();

			String query = "SELECT company FROM companylist WHERE KATEGORIE LIKE '%일식%'";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				values.add(rs.getString(1));
//				System.out.println(rs.getString(1));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return values;
	}
	
	public ArrayList<String> WesternList(String info) {
		ArrayList<String> values = new ArrayList<String>();
		try {
			connDB();

			String query = "SELECT company FROM companylist WHERE KATEGORIE LIKE '%양식%'";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				values.add(rs.getString(1));
//				System.out.println(rs.getString(1));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return values;
	}
	
	public ArrayList<String> SnackList(String info) {
		ArrayList<String> values = new ArrayList<String>();
		try {
			connDB();

			String query = "SELECT company FROM companylist WHERE KATEGORIE LIKE '%분식%'";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				values.add(rs.getString(1));
//				System.out.println(rs.getString(1));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return values;
	}
	
	public ArrayList<String> BuffetList(String info) {
		ArrayList<String> values = new ArrayList<String>();
		try {
			connDB();

			String query = "SELECT company FROM companylist WHERE KATEGORIE LIKE '%뷔페식%'";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				values.add(rs.getString(1));
//				System.out.println(rs.getString(1));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return values;
	}
	
	public ArrayList<String> EtcList(String info) {
		ArrayList<String> values = new ArrayList<String>();
		try {
			connDB();

			String query = "SELECT company FROM companylist WHERE KATEGORIE LIKE '%기타%'";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				values.add(rs.getString(1));
//				System.out.println(rs.getString(1));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return values;
	}

//	public ArrayList<String> Flist(String info) {
//		ArrayList<String> values = new ArrayList<String>();
//		try {
//			connDB();
//
//			String query = "SELECT " + info + " FROM food";
//			System.out.println("SQL : " + query);
//			rs = stmt.executeQuery(query);
//
//			while (rs.next()) {
//				values.add(rs.getString(1));
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return values;
//	}
//
	public CompanyListVo Foodinfo(String foodName) {
		CompanyListVo info = new CompanyListVo();
		try {
			connDB();

			String query = "SELECT COMPANY, mainmenu, telnumber, address FROM CompanyList WHERE COMPANY = '" + foodName + "'";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			rs.next();
			info.setCompany(rs.getString(1));
			info.setMainMemu(rs.getString(2));
			info.setTelNumber(rs.getString(3));
			info.setAddress(rs.getString(4));

		} catch (Exception e) {
			e.printStackTrace();
		}

		return info;
	}
	
	public ArrayList<CompanyListVo> SearchFoodList(String word) {
		ArrayList<CompanyListVo> list = new ArrayList<CompanyListVo>();
		try {
			connDB();

			String query = "SELECT * FROM companylist WHERE COMPANY LIKE '%" + word + "%' AND KATEGORIE LIKE '%한식%'";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				CompanyListVo vo = new CompanyListVo();
				vo.setCompany(rs.getString(2));
				System.out.println(rs.getString(2));
				list.add(vo);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public void connDB() {
		try {
			Class.forName(driver);
			System.out.println("jdbc driver loading success.");
			con = DriverManager.getConnection(url, user, password);
			System.out.println("oracle connection success.\n");
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			System.out.println("statement create success.\n");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	public static void main(String[] args) {
//		CompanyListDAO cldao = new CompanyListDAO();
//		cldao.SearchFoodList("솔밭");
//	}
}
