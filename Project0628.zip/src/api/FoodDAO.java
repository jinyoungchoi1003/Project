package api;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class FoodDAO {
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String user = "c##green";
	String password = "green1234";

	private Connection con;
	private Statement stmt;
	private ResultSet rs;

	public boolean FoodList(FoodVO f) {
		try {
			connDB();

			String query = "insert into food(company,foodtype,city,address,phonenumber,mainmenu)values('"
					+ f.getCompany() + "','" + f.getFoodType() + "','" + f.getCity() + "','" + f.getAddress() + "','"
					+ f.getPhoneNumber() + "','" + f.getMainMemu() + "')";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);
			System.out.println("rs.getRow() : " + rs.getRow());

			if (rs.getRow() == 0) {
				System.out.println("0 row selected...");
			} else {
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	public ArrayList<String> Flist(String info) {
		ArrayList<String> values = new ArrayList<String>();
		try {
			connDB();

			String query = "SELECT " + info + " FROM food";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				values.add(rs.getString(1));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return values;
	}

	public FoodVO Foodinfo(String foodName) {
		FoodVO info = new FoodVO();
		try {
			connDB();

			String query = "SELECT COMPANY, address, phonenumber, mainmenu FROM food WHERE COMPANY = '" + foodName + "'";
			System.out.println("SQL : " + query);
			rs = stmt.executeQuery(query);

			rs.next();
			info.setCompany(rs.getString(1));
			info.setAddress(rs.getString(2));
			info.setPhoneNumber(rs.getString(3));
			info.setMainMemu(rs.getString(4));

		} catch (Exception e) {
			e.printStackTrace();
		}

		return info;
	}

	public void connDB() {
		try {
			Class.forName(driver);
			System.out.println("jdbc driver loading success.");
			con = DriverManager.getConnection(url, user, password);
			System.out.println("oracle connection success.\n");
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			System.out.println("statement create success.\n");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	public static void main(String[] args) {
//		FoodDAO fd = new FoodDAO();
//		fd.Foodinfo(null);
//		
//	}

}
