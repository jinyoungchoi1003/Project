package api;

public class CompanyListVo {
	private String kategorie;
	private String company;
	private String mainMemu;
	private String telNumber;
	private String ctprvnNm;
	private String signguNm;
	private String address;

	public CompanyListVo() {

	}
	
	public CompanyListVo(String company) {
		this.company = company;
	}

	public CompanyListVo(String kategorie, String company, String mainMemu, String telNumber, String ctprvnNm,
			String signguNm, String address) {
		this.kategorie = kategorie;
		this.company = company;
		this.mainMemu = mainMemu;
		this.telNumber = telNumber;
		this.ctprvnNm = ctprvnNm;
		this.signguNm = signguNm;
		this.address = address;
	}

	public String getKategorie() {
		return kategorie;
	}

	public String getCompany() {
		return company;
	}

	public String getMainMemu() {
		return mainMemu;
	}

	public String getTelNumber() {
		return telNumber;
	}

	public String getCtprvnNm() {
		return ctprvnNm;
	}

	public String getSignguNm() {
		return signguNm;
	}

	public String getAddress() {
		return address;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public void setMainMemu(String mainMemu) {
		this.mainMemu = mainMemu;
	}

	public void setTelNumber(String telNumber) {
		this.telNumber = telNumber;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
