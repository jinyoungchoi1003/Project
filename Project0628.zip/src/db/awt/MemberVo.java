package db.awt;

public class MemberVo {
	private String id;
	private String password;
//	private String checkPwd;	
	private String nickname;
	private String email;
	public static MemberVo user;
	
	public static void userInit(MemberVo v) {
		 user = v;
	}

	public MemberVo() {

	}

	public MemberVo(String id, String password) {
		this.id = id;
		this.password = password;
	}
	
	public MemberVo(String id, String password, String nickname, String email) {
		this.id = id;
		this.password = password;
//		this.checkPwd = checkPwd;
		this.nickname = nickname;
		this.email = email;
	}
	
	public String getId() {
		return id;
	}

	public String getPassword() {
		return password;
	}
	
//	public String getCheckPwd() {
//		return checkPwd;
//	}
	
	public String getNickname() {
		return nickname;
	}
	
	public String getEmail() {
		return email;
	}
	
	
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
