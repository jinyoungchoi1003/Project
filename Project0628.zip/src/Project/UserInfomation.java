package Project;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import db.awt.MemberDAO;
import db.awt.MemberVo;

public class UserInfomation {

	private JFrame frmInfomation;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					UserInfomation window = new UserInfomation();
//					window.frmInfomation.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public UserInfomation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmInfomation = new JFrame();
		frmInfomation.getContentPane().setFocusable(false);
		frmInfomation.setTitle("Infomation");
		frmInfomation.setBounds(100, 100, 800, 600);
		frmInfomation.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmInfomation.getContentPane().setLayout(null);
		frmInfomation.setLocationRelativeTo(null);
		frmInfomation.setResizable(false);

		JLabel titleLabel = new JLabel("회원 정보");
		titleLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 60));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setBounds(275, 58, 223, 80);
		frmInfomation.getContentPane().add(titleLabel);

		JLabel idLabel = new JLabel("아이디");
		idLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		idLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 50));
		idLabel.setBounds(124, 176, 142, 52);
		frmInfomation.getContentPane().add(idLabel);

		JLabel nickLabel = new JLabel("닉네임");
		nickLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		nickLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 50));
		nickLabel.setBounds(124, 289, 142, 52);
		frmInfomation.getContentPane().add(nickLabel);

		JLabel emailLabel = new JLabel("이메일");
		emailLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		emailLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 50));
		emailLabel.setBounds(124, 390, 142, 52);
		frmInfomation.getContentPane().add(emailLabel);

		JButton pwdChagebtn_1_1 = new JButton("회원정보 수정");
		pwdChagebtn_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmInfomation.setVisible(false);
				new UpdateInfo();
			}
		});
		pwdChagebtn_1_1.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		pwdChagebtn_1_1.setBounds(621, 10, 153, 52);
		frmInfomation.getContentPane().add(pwdChagebtn_1_1);

		JButton pwdChagebtn_1_1_1 = new JButton("회원탈퇴");
		pwdChagebtn_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = 0;
				result = JOptionPane.showConfirmDialog(null, "고객의 모든 정보가 삭제됩니다.\n탈퇴하시겠습니까?", "회원탈퇴",
						JOptionPane.YES_NO_OPTION);
				if (result == 0) {
					MemberDAO dao = new MemberDAO();
					if (dao.ReSign(MemberVo.user.getId()) > 0) {
						JOptionPane.showMessageDialog(null, "회원탈퇴 되었습니다.\n이용해주셔서 감사합니다.");
						System.exit(0);
					} else {
						JOptionPane.showMessageDialog(null, "회원탈퇴에 실패했습니다.\n관리자에게 문의해주세요.");
					}
				}
			}
		});
		pwdChagebtn_1_1_1.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		pwdChagebtn_1_1_1.setBounds(649, 501, 125, 52);
		frmInfomation.getContentPane().add(pwdChagebtn_1_1_1);

		JLabel idInfoLabel = new JLabel("");
		idInfoLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		idInfoLabel.setBounds(295, 176, 203, 52);
		idInfoLabel.setText(MemberVo.user.getId());
		frmInfomation.getContentPane().add(idInfoLabel);

		JLabel nickInfoLabel = new JLabel("");
		nickInfoLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		nickInfoLabel.setBounds(295, 292, 203, 52);
		nickInfoLabel.setText(MemberVo.user.getNickname());
		frmInfomation.getContentPane().add(nickInfoLabel);

		JLabel emailInfoLabel = new JLabel("");
		emailInfoLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		emailInfoLabel.setBounds(295, 391, 419, 57);
		emailInfoLabel.setText(MemberVo.user.getEmail());
		frmInfomation.getContentPane().add(emailInfoLabel);

		JButton pwdChagebtn_1_1_1_1 = new JButton("로그아웃");
		pwdChagebtn_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = 0;
				result = JOptionPane.showConfirmDialog(null, "로그아웃을 하시겠습니까?", "로그아웃", JOptionPane.YES_NO_OPTION);
				if (result == 0) {
					frmInfomation.setVisible(false);
					new Login();
				}
			}
		});
		pwdChagebtn_1_1_1_1.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		pwdChagebtn_1_1_1_1.setBounds(512, 501, 125, 52);
		frmInfomation.getContentPane().add(pwdChagebtn_1_1_1_1);

		JButton pwdChagebtn_1_1_1_1_1 = new JButton("뒤로가기");
		pwdChagebtn_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmInfomation.setVisible(false);
				new Main();
			}
		});
		pwdChagebtn_1_1_1_1_1.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		pwdChagebtn_1_1_1_1_1.setBounds(12, 10, 140, 50);
		frmInfomation.getContentPane().add(pwdChagebtn_1_1_1_1_1);

		frmInfomation.setVisible(true);
	}
}
