package Project;

//import java.awt.EventQueue;

import javax.swing.JFrame;


import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import api.CompanyListDAO;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.AbstractListModel;
import javax.swing.JScrollPane;

public class Search implements ActionListener {

	private JFrame frame;
	private JComboBox<String> guComboBox, dongComboBox;
	private ArrayList<String> values;
	private JList<String> foods;
//	private JScrollBar scrollbar;
	private JScrollPane scrollpane;

	String[][] dong = {
			{ "선택", "신흥1", "신흥2", "신흥3", "태평1", "태평2", "태평3", "태평4", "수진1", "수진2", "단대", "산성", "양지", "복정", "신촌", "고등",
					"시흥" },
			{ "선택", "성남", "중앙", "금광1", "금광2", "은행1", "은행2", "상대원1", "상대원2", "상대원3", "하대원", "도촌" },
			{ "선택", "분당", "수내1", "수내2", "수내3", "정자1", "정자2", "정자3", "서현1", "서현2", "이매1", "이매2", "야탑1", "야탑2", "야탑3",
					"금곡", "구미", "구미1", "삼평", "판교", "백현", "운중" } };

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Search window = new Search();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public Search() {
		initialize();
	}

	public JFrame getFrame() {
		return frame;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 904, 570);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		JLabel foodSearch = new JLabel("음식점 검색");
		foodSearch.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		foodSearch.setHorizontalAlignment(SwingConstants.CENTER);
		foodSearch.setBounds(275, 70, 340, 85);
		frame.getContentPane().add(foodSearch);

		guComboBox = new JComboBox<String>();
		guComboBox.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		guComboBox.setModel(new DefaultComboBoxModel<String>(new String[] { "선택", "수정", "중원", "분당" }));
		guComboBox.setBounds(260, 165, 130, 40);
		frame.getContentPane().add(guComboBox);

		JLabel lblNewLabel_1_1_1 = new JLabel("구");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		lblNewLabel_1_1_1.setBounds(400, 165, 70, 40);
		frame.getContentPane().add(lblNewLabel_1_1_1);

		dongComboBox = new JComboBox<String>();
		dongComboBox.setModel(new DefaultComboBoxModel<String>(new String[] { "선택" }));
		dongComboBox.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		dongComboBox.setBounds(482, 165, 133, 40);
		frame.getContentPane().add(dongComboBox);

		JLabel lblNewLabel_1_1 = new JLabel("동");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(610, 165, 70, 40);
		frame.getContentPane().add(lblNewLabel_1_1);

		scrollpane = new JScrollPane();

		values = new CompanyListDAO().CompanyList("company");

//		JScrollPane scrollPane = new JScrollPane();
		scrollpane.setBounds(260, 223, 420, 283);
		frame.getContentPane().add(scrollpane);
		foods = new JList<String>();
		scrollpane.setViewportView(foods);
		foods.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		foods.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		foods.setModel(new AbstractListModel<String>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public int getSize() {
				return values.size();
			}

			public String getElementAt(int index) {
				return values.get(index);
			}
		});
		foods.addListSelectionListener(new ListSelectionListener() {

			public void valueChanged(ListSelectionEvent e) {
				@SuppressWarnings("unchecked")
				JList<String> list = (JList<String>) e.getSource();
				values.get(list.getSelectedIndex());
				String name = values.get(list.getSelectedIndex());

//				System.out.println(name);
//				JOptionPane.showMessageDialog(null, "준비중입니다.");
				frame.setVisible(false);
				// MainPage.Infomation().getFrame().setVisible(true);
				// new Infomation().getFrame().setVisible(true);
				new CompanyInfomation(name);
			}
		});
//		scrollPane.add(foods);

		JButton btnNewButton_4 = new JButton("뒤로가기");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
//				MainPage.kategorie().getFrame().setVisible(true);
//				new Kategorie().getFrame().setVisible(true);
				new Kategorie();
			}
		});
		btnNewButton_4.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		btnNewButton_4.setBounds(12, 10, 150, 40);
		frame.getContentPane().add(btnNewButton_4);

		guComboBox.addActionListener(this);
	}

//	@Override
//	public void valueChanged(ListSelectionEvent e) {
//		JList<String> list = (JList<String>) e.getSource();
//		JOptionPane.showMessageDialog(null, "준비중입니다.");
//		frame.setVisible(false);
////			MainPage.Infomation().getFrame().setVisible(true);
////			new Infomation().getFrame().setVisible(true);
//		new Infomation();
//
//	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (guComboBox.getSelectedIndex() == 0) {
			JOptionPane.showMessageDialog(null, "구를 선택해주세요.");
			System.out.println(guComboBox.getSelectedIndex());
		} else {
			dongComboBox.setModel(new DefaultComboBoxModel<String>(dong[guComboBox.getSelectedIndex() - 1]));
		}

	}
}
