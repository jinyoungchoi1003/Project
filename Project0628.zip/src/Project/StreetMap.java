//package Project;
//
//import java.awt.EventQueue;
//
//import javax.swing.JFrame;
//import javax.swing.JButton;
//import java.awt.event.ActionListener;
//import java.awt.event.ActionEvent;
//import java.awt.Font;
//import javax.swing.JLabel;
//import javax.swing.ImageIcon;
//
//public class StreetMap {
//
//	private JFrame frame;
//
//	/**
//	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					StreetMap window = new StreetMap();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
//
//	/**
//	 * Create the application.
//	 */
//	public StreetMap() {
//		initialize();
//	}
//
//	public JFrame getFrame() {
//		return frame;
//	}
//
//	/**
//	 * Initialize the contents of the frame.
//	 */
//	private void initialize() {
//		frame = new JFrame();
//		frame.setBounds(100, 100, 580, 500);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		frame.getContentPane().setLayout(null);
//		frame.setLocationRelativeTo(null);
//		
//		JButton btnNewButton = new JButton("뒤로가기");
//		btnNewButton.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
//		btnNewButton.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				frame.setVisible(false);
////				MainPage.Infomation().getFrame().setVisible(true);
//				new Infomation().getFrame().setVisible(true);
//			}
//		});
//		btnNewButton.setBounds(12, 10, 130, 30);
//		frame.getContentPane().add(btnNewButton);
//		
//		JLabel lblNewLabel = new JLabel("");
//		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\화면 캡처 2022-06-29 154835.png"));
//		lblNewLabel.setBounds(22, 50, 532, 403);
//		frame.getContentPane().add(lblNewLabel);
//	}
//}
