package Project;

import java.awt.Desktop;

//import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import api.CompanyListDAO;
import api.CompanyListVo;
import javax.swing.ImageIcon;
import java.awt.Cursor;

public class CompanyInfomation {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Infomation window = new Infomation("");
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//
//	}

	/**
	 * Create the application.
	 * 
	 * @throws URISyntaxException
	 */
	public CompanyInfomation(String name) {
		try {
			initialize(name);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public JFrame getFrame() {
		return frame;
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * @throws URISyntaxException
	 */
	private void initialize(String name) throws URISyntaxException {
		final URI uri = new URI("file:///D:/work/Project0628/src/Project/StreetMap.html");
		frame = new JFrame("Infomation");
		frame.setBounds(100, 100, 800, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		JButton Backbtn = new JButton("");
		Backbtn.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\back.png"));
		Backbtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Backbtn.setFocusPainted(false);
		Backbtn.setBorderPainted(false);
		Backbtn.setBorder(null);
		Backbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				BackButton.backPageGO();
			}
		});
		Backbtn.setFont(new Font("배달의민족 주아", Font.BOLD, 25));
		Backbtn.setBounds(12, 10, 140, 50);
		frame.getContentPane().add(Backbtn);

		JButton btnNewButton_4_1 = new JButton("");
		btnNewButton_4_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_4_1.setBorderPainted(false);
		btnNewButton_4_1.setBorder(null);
		btnNewButton_4_1.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\지.png"));
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "준비중 입니다.");
//				frame.setVisible(false);
////				MainPage.streetmap().getFrame().setVisible(true);
//				new StreetMap().getFrame().setVisible(true);
				open(uri);

			}
		});
		btnNewButton_4_1.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		btnNewButton_4_1.setBounds(263, 672, 280, 80);
		frame.getContentPane().add(btnNewButton_4_1);

//		JLabel lblNewLabel = new JLabel("");
//		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\KakaoTalk_20220628_142955563.jpg"));
//		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
//		lblNewLabel.setBounds(12, 64, 762, 254);
//		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("음식점 정보");
		lblNewLabel_1.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(12, 323, 762, 71);
		frame.getContentPane().add(lblNewLabel_1);

		JLabel foods = new JLabel();
//		FoodDAO fdao = new FoodDAO();
		CompanyListDAO cldao = new CompanyListDAO();
		CompanyListVo clvo = cldao.Foodinfo(name);
		String foodInfoString = "<html>" + "Company : " + clvo.getCompany() + "<br><br>" + "MainMenu : "
				+ clvo.getMainMemu() + "<br><br>" + "Tel. " + clvo.getTelNumber() + "<br><br>" + "Address : "
				+ clvo.getAddress() + "</html>";
		foods.setFont(new Font("배달의민족 주아", Font.BOLD, 24));
		foods.setText(foodInfoString);

		foods.setBounds(12, 404, 762, 258);
		frame.getContentPane().add(foods);
		
		JLabel lblNewLabel = new JLabel("이미지는 준비중 입니다.");
		lblNewLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 70));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(12, 64, 762, 258);
		frame.getContentPane().add(lblNewLabel);
	}

	private static void open(URI uri) {
		if (Desktop.isDesktopSupported()) {
			try {
				Desktop.getDesktop().browse(uri);
			} catch (IOException e) {
				/* TODO: error handling */ }
		} else {
			/* TODO: error handling */ }
	}
}
