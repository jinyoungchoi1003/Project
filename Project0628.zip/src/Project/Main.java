package Project;

import javax.swing.JFrame;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
//import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Cursor;


public class Main {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Main window = new Main();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}

	public JFrame getFrame() {
		return frame;
	}

	/**
	 * ` Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Main");
		frame.setBounds(100, 100, 800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		JButton btnNewButton = new JButton("");
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.setFocusPainted(false);
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\랜.png"));
		btnNewButton.setBorderPainted(false);
		btnNewButton.setBorder(null);
		btnNewButton.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
//				MainPage.random().getFrame().setVisible(true);
//				new Random().getFrame().setVisible(true);
				new Random();

			}
		});
		btnNewButton.setBounds(127, 158, 250, 150);
		frame.getContentPane().add(btnNewButton);

		JLabel lblNewLabel = new JLabel("메인 페이지");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		lblNewLabel.setBounds(215, 29, 354, 98);
		frame.getContentPane().add(lblNewLabel);

		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_1.setFocusPainted(false);
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\카.png"));
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBorder(null);
		btnNewButton_1.setFont(new Font("배달의민족 주아", Font.BOLD, 30));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
//				MainPage.kategorie().getFrame().setVisible(true);
//				new Kategorie().getFrame().setVisible(true);
				new Kategorie();
			}
		});
		btnNewButton_1.setBounds(399, 158, 250, 150);
		frame.getContentPane().add(btnNewButton_1);

//		JButton btnNewButton_4 = new JButton("로그아웃");
//		btnNewButton_4.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				int result = 0;
//				result = JOptionPane.showConfirmDialog(null, "로그아웃을 하시겠습니까?", "로그아웃", JOptionPane.YES_NO_OPTION);
//				if (result == 0) {
//					frame.setVisible(false);
////					MainPage.login().getFrmLogin().setVisible(true);
////					new Login().getFrmLogin().setVisible(true);
//					new Login();
//				}
//			}
//		});
//		btnNewButton_4.setFont(new Font("배달의민족 주아", Font.BOLD, 15));
//		btnNewButton_4.setBounds(12, 12, 130, 30);
//		frame.getContentPane().add(btnNewButton_4);

//		JLabel lblNewLabel_1 = new JLabel(MemberVo.user.getNickname() + "님");
//		lblNewLabel_1.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
//		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
//		lblNewLabel_1.setBounds(605, 10, 262, 30);
//		frame.getContentPane().add(lblNewLabel_1); // ㅈ 버그

		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\회.png"));
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_2.setFocusPainted(false);
		btnNewButton_2.setForeground(Color.BLACK);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				new UserInfomation();
			}
		});
		btnNewButton_2.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		btnNewButton_2.setBounds(127, 318, 250, 150);
		frame.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_2_1 = new JButton("");
		btnNewButton_2_1.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\도.png"));
		btnNewButton_2_1.setBorderPainted(false);
		btnNewButton_2_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_2_1.setFocusPainted(false);
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				new Help();
			}
		});
		btnNewButton_2_1.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		btnNewButton_2_1.setBounds(399, 318, 250, 150);
		frame.getContentPane().add(btnNewButton_2_1);
	}

}