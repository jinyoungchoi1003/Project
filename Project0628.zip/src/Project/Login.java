package Project;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;

//import java.awt.EventQueue;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import db.awt.MemberDAO;
import db.awt.MemberVo;

public class Login {
	private JFrame frmLogin;
	private JTextField txtId;
	private JPasswordField txtPwd;
	private MemberDAO dao;
	private JButton loginBtn, signupBtn;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Login window = new Login();
//					window.frmLogin.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			SwingUtilities.updateComponentTreeUI(frmLogin);
		} catch (Exception e) {

		}

		dao = new MemberDAO();

		frmLogin = new JFrame();
		frmLogin.setFont(new Font("배달의민족 주아", Font.BOLD, 15));
		frmLogin.setSize(new Dimension(600, 350));
		frmLogin.setTitle("Login");
		frmLogin.getContentPane().setBackground(new Color(192, 192, 192));
		frmLogin.setBounds(100, 100, 600, 350);
		frmLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLogin.getContentPane().setLayout(null);
		frmLogin.setLocationRelativeTo(null);
		frmLogin.setResizable(false);

		txtId = new JTextField();
		txtId.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (txtId.getText().equals("ID")) {
					txtId.setText("");
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (txtId.getText().equals("")) {
					txtId.setText("ID");
				}
			}
		});
		txtId.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		txtId.setText("ID");
		txtId.setBounds(12, 242, 450, 20);
		frmLogin.getContentPane().add(txtId);
		txtId.setColumns(10);

		txtPwd = new JPasswordField();
		txtPwd.addFocusListener(new FocusAdapter() {
			@SuppressWarnings("deprecation")
			@Override
			public void focusGained(FocusEvent e) {
				if (txtPwd.getText().equals("PASSWORD")) {
					txtPwd.setText("");
				}
			}

			@SuppressWarnings("deprecation")
			@Override
			public void focusLost(FocusEvent e) {
				if (txtPwd.getText().equals("")) {
					txtPwd.setText("PASSWORD");
				}
			}
		});
		txtPwd.setHorizontalAlignment(SwingConstants.LEFT);
		txtPwd.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		txtPwd.setText("PASSWORD");
		txtPwd.setBounds(12, 272, 450, 21);
		frmLogin.getContentPane().add(txtPwd);

		loginBtn = new JButton("로그인");
		frmLogin.getRootPane().setDefaultButton(loginBtn);
		loginBtn.requestFocus(true);
		loginBtn.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int key = e.getKeyCode();
				if (key == KeyEvent.VK_ENTER) {
					Toolkit.getDefaultToolkit().beep();
					loginBtn.doClick();
				}
			}
		});
		loginBtn.setFont(new Font("배달의민족 주아", Font.BOLD, 15));
		loginBtn.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
//				if(txtPwd.getText().equals("' or 1=1 --")) {
//					JOptionPane.showMessageDialog(null, "잘못된 접근입니다. 시스템을 종료합니다.");
//					System.exit(0);
//				} else 
					if (txtId.getText().equals("") && (txtPwd.getText().equals(""))) {
					JOptionPane.showMessageDialog(null, "아이디 또는 패스워드를 입력해주세요.");
				} else if (txtId.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "아이디를 입력해주세요.");
				} else if (txtPwd.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "비밀번호를 입력해주세요.");
				} else {
					System.out.println(txtId.getText());
					System.out.println(txtPwd.getText());
					MemberVo vo = new MemberVo(txtId.getText(), txtPwd.getText());
					MemberVo b = dao.list(vo);
					// tfMsg.setText(String.valueOf(b));
					if (b != null) {
						JOptionPane.showMessageDialog(null, "로그인이 성공적으로 되었습니다.");
						MemberVo.userInit(b);
						System.out.println(MemberVo.user.getNickname() + "님이 로그인하셨습니다.");
						JOptionPane.showMessageDialog(null, MemberVo.user.getNickname() + "님이 로그인하셨습니다.");
						frmLogin.setVisible(false);
						new Main();
					} else {
						JOptionPane.showMessageDialog(null, "아이디 또는 패스워드를 확인해 주세요");
					}
				}
			}
		});
		loginBtn.setBounds(474, 243, 100, 50);
		frmLogin.getContentPane().add(loginBtn);

		signupBtn = new JButton("Sign Up");
		signupBtn.setFocusable(false);
		signupBtn.setFont(new Font("배달의민족 주아", Font.BOLD, 15));
		signupBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmLogin.setVisible(false);
				new SignUp();
			}
		});
		signupBtn.setBounds(474, 10, 100, 30);
		frmLogin.getContentPane().add(signupBtn);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(Color.BLACK);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel
				.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\istockphoto-1184239215-1024x1024.png"));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("돋움", Font.BOLD, 40));
		lblNewLabel.setBounds(12, 50, 562, 182);
		frmLogin.getContentPane().add(lblNewLabel);
		frmLogin.setVisible(true);
	}
}
