import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class JsonSimple {

	public static void main(String[] args) {
		try {
			String urlStr = "https://openapi.gg.go.kr/Genrestrtchifood";

			String serviceKey = "ee5c14b8734b4c1eac0c044d1d58f13f";

//			String urlStr = URLEncoder
//					.encode("http://openapi.q-net.or.kr/api/service/rest/InquiryListNationalQualifcationSVC", "UTF-8");
			urlStr += "?" + URLEncoder.encode("Key", "UTF-8") + "=" + serviceKey;
			urlStr += "&" + URLEncoder.encode("Type", "UTF-8") + "=json";
			urlStr += "&" + URLEncoder.encode("pIndex", "UTF-8") + "=1";
			urlStr += "&" + URLEncoder.encode("pSize", "UTF-8") + "=50";
			urlStr += "&" + URLEncoder.encode("SIGUN_NM", "UTF-8") + "=성남시";

//			urlStr += "&" + URLEncoder.encode("implYy", "UTF-8") + "=";

			URL url = new URL(urlStr);

			String line = "";
			String result = "";

			BufferedReader br;
			br = new BufferedReader(new InputStreamReader(url.openStream()));
			while ((line = br.readLine()) != null) {
				result = result.concat(line);
				System.out.println(line);
			}

//			HttpEntity entity = new HttpEntity(header);
//			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
			JSONParser parser = new JSONParser();
			JSONObject obj = (JSONObject) parser.parse(result);
//			JSONObject obj = (JSONObject) parser.parse(response.getBody());

			JSONArray parse_itemsArr = (JSONArray) obj.get("row");

//			JSONArray parse_itemsArr = (JSONArray) ((JSONObject) ((JSONObject) obj.get("response")).get("result"))
//					.get("items");

//			String miseType = "";
			for (int i = 0; i < parse_itemsArr.size(); i++) {
				JSONObject exam = (JSONObject) parse_itemsArr.get(i);
//				String implSeq = (String) exam.get("implSeq"); // 발령지역
//				String qualgbCd = (String) exam.get("qualgbCd"); // 발령지역
//				String gu = (String) exam.get("구"); // 행정구
//				String address = (String) exam.get("도로명전체주소"); // 도로명전체주소
//				String address2 = (String) exam.get("소재지전체주소"); // 소재지전체주소
				String BIZPLC_NM = (String) exam.get("BIZPLC_NM"); // 사업장명
//				name.replace("'","/");
//				String name2 = (String) exam.get("업종명"); // 업종명
//				String docExamStartDt = (String) exam.get("docExamStartDt"); // 발령일자
//				String docExamEndDt = (String) exam.get("docExamEndDt"); // 발령시간
//				String docPassDt = (String) exam.get("docPassDt"); // 발령농도
//				String pracRegStartDt = (String) exam.get("pracRegStartDt"); // 미세먼지 구분 PM10, PM25
//				String pracRegEndDt = (String) exam.get("pracRegEndDt"); // 경보단계 : 주의보/경보
//				String pracExamStartDt = (String) exam.get("pracExamStartDt"); // 해제일자
//				String pracExamEndDt = (String) exam.get("pracExamEndDt"); // 해제시간
//				String pracPassDt = (String) exam.get("pracPassDt"); // 해제시 미세먼지농도

				StringBuffer sb = new StringBuffer();
				sb.append("BIZPLC_NM : " + BIZPLC_NM);
//				sb.append("구 : " + implYy);
//				sb.append("도로명전체주소 : " + qualgbNm);
//				sb.append("사업장명 : " + docRegStartDt);

//				System.out.println("구 : " + gu);
//				System.out.println("도로명전체주소 : " + address);
//				System.out.println("소재지전체주소 : " + address2);
//				System.out.println("사업장명 : " + name);
//				System.out.println("업종명 : " + name2);
				System.out.println(sb.toString());
			}

			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}