package Project;

//import java.awt.EventQueue;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
//import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import java.awt.Cursor;

public class Random {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Random window = new Random();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public Random() {
		initialize();
	}

	public JFrame getFrame() {
		return frame;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Random");
		frame.setBounds(100, 100, 800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		JLabel lblNewLabel = new JLabel("랜 덤 추 천");
		lblNewLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(266, 66, 230, 80);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setFont(new Font("배달의민족 주아", Font.BOLD, 50));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(12, 156, 762, 298);
		frame.getContentPane().add(lblNewLabel_1);

		JButton btnNewButton = new JButton("");
		btnNewButton.setBorderPainted(false);
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\start.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] foods = { "라면", "김치찌개", "된장찌개", "삼겹살" };
				double random = Math.random();
				int num = (int) Math.round(random * (foods.length - 1));
				// JOptionPane.showMessageDialog(null, "추첨을 시작합니다.");
//				JOptionPane.showMessageDialog(null, "오늘의 추천 메뉴는 " + foods[num] + "입니다.");
				lblNewLabel_1.setText(foods[num]);
			}
		});
		btnNewButton.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		btnNewButton.setBounds(235, 464, 300, 70);
		frame.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_1.setFocusPainted(false);
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBorder(null);
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\back.png"));
		btnNewButton_1.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
//				MainPage.main().getFrame().setVisible(true);
//				new Main().getFrame().setVisible(true);
				new Main();
			}
		});
		btnNewButton_1.setBounds(12, 10, 140, 50);
		frame.getContentPane().add(btnNewButton_1);
	}
}
