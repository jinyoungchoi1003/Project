package Project;

import java.util.Stack;

public class BackButton {
	private static Stack<Integer> backPage = new Stack<Integer>();

	public static void backPageAdd(int num) {
		backPage.add(num);
	}

	public static void backPageGO() {
		if (!backPage.isEmpty()) {
			switch (backPage.pop()) {
			case KoreanFoodList.PageNumber:
				new KoreanFoodList();
				break;
			case ChineseFoodList.PageNumber:
				new ChineseFoodList();
				break;
			case JapaneseFoodList.PageNumber:
				new JapaneseFoodList();
				break;
			case WesternFoodList.PageNumber:
				new WesternFoodList();
				break;
			case SnackFoodList.PageNumber:
				new SnackFoodList();
				break;
			case BuffetFoodList.PageNumber:
				new BuffetFoodList();
				break;
			case EtcFoodList.PageNumber:
				new EtcFoodList();
				break;
			}
		}
	}
}
