package Project;

//import java.awt.EventQueue;
import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.AbstractListModel;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import api.CompanyListDAO;

import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;

public class SnackFoodList {
	
	public static final int PageNumber = 5;

	private JFrame frame;
	private JList<String> list;
	private JScrollPane scrollPane;
	private ArrayList<String> values;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					KoreanFoodList window = new KoreanFoodList();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public SnackFoodList() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings("unchecked")
	private void initialize() {
		frame = new JFrame("SnackFoodList");
		frame.setBounds(100, 100, 800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		scrollPane = new JScrollPane();

		values = new CompanyListDAO().SnackList("company");

		scrollPane.setBounds(12, 142, 758, 411);
		frame.getContentPane().add(scrollPane);
		list = new JList<String>();
		scrollPane.setViewportView(list);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		list.setModel(new AbstractListModel<String>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public int getSize() {
				return values.size();
			}

			public String getElementAt(int index) {
				return values.get(index);
			}
		});
		
				list.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						JList<String> list = (JList<String>) e.getSource();
						String name = list.getSelectedValue();
		
						frame.setVisible(false);
						BackButton.backPageAdd(SnackFoodList.PageNumber);
						new CompanyInfomation(name);
					}
				});

		JLabel lblNewLabel = new JLabel("음식점 검색");
		lblNewLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(12, 92, 140, 40);
		frame.getContentPane().add(lblNewLabel);

		textField = new JTextField();
		textField.setFont(new Font("배달의민족 주아", Font.BOLD, 30));
		textField.setBounds(164, 90, 405, 40);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		JButton btnNewButton_1 = new JButton("검색");
		btnNewButton_1.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		btnNewButton_1.setBounds(581, 92, 130, 40);
		frame.getContentPane().add(btnNewButton_1);

		JButton btnNewButton = new JButton("뒤로가기");
		btnNewButton.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				new Kategorie();
			}
		});
		btnNewButton.setBounds(12, 10, 140, 50);
		frame.getContentPane().add(btnNewButton);

		frame.setVisible(true);

	}

}
