package Project;

//import java.awt.EventQueue;

import javax.swing.JFrame;



import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Cursor;

public class Kategorie {
	
//	private JButton KoreanListBtn;
//	private JButton ChineseListBtn;

	private JFrame frmKategorie;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Kategorie window = new Kategorie();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public Kategorie() {
		initialize();
	}

	public JFrame getFrame() {
		return frmKategorie;
	}
	
//	public JButton getKoreanListBtn() {
//		return KoreanListBtn;
//	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmKategorie = new JFrame();
		frmKategorie.setTitle("Kategorie");
		frmKategorie.setBounds(100, 100, 800, 600);
		frmKategorie.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmKategorie.getContentPane().setLayout(null);
		frmKategorie.setLocationRelativeTo(null);
		frmKategorie.setVisible(true);

		JLabel lblNewLabel = new JLabel("카테고리");
		lblNewLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 50));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(300, 55, 189, 63);
		frmKategorie.getContentPane().add(lblNewLabel);

		JButton KoreanListBtn = new JButton("");
		KoreanListBtn.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\한식.png"));
		KoreanListBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		KoreanListBtn.setFocusPainted(false);
		KoreanListBtn.setBorderPainted(false);
		KoreanListBtn.setForeground(Color.WHITE);
		KoreanListBtn.setContentAreaFilled(false);
		KoreanListBtn.setOpaque(false);
		KoreanListBtn.setBackground(Color.BLACK);
		KoreanListBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmKategorie.setVisible(false);
				new KoreanFoodList();
			}
		});
		KoreanListBtn.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		KoreanListBtn.setBounds(50, 195, 150, 86);
		frmKategorie.getContentPane().add(KoreanListBtn);

		JButton ChineseListBtn = new JButton("");
		ChineseListBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		ChineseListBtn.setFocusPainted(false);
		ChineseListBtn.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\중식.png"));
		ChineseListBtn.setBorderPainted(false);
		ChineseListBtn.setBorder(null);
		ChineseListBtn.setActionCommand("wndtlr");
		ChineseListBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmKategorie.setVisible(false);
				new ChineseFoodList();
			}
		});
		ChineseListBtn.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		ChineseListBtn.setBounds(230, 195, 150, 86);
		frmKategorie.getContentPane().add(ChineseListBtn);

		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_2.setFocusPainted(false);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBorder(null);
		btnNewButton_2.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\일식.png"));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmKategorie.setVisible(false);
				new JapaneseFoodList();
			}
		});
		btnNewButton_2.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		btnNewButton_2.setBounds(410, 195, 150, 86);
		frmKategorie.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_3.setFocusPainted(false);
		btnNewButton_3.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\양식4.png"));
		btnNewButton_3.setBorderPainted(false);
		btnNewButton_3.setBorder(null);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmKategorie.setVisible(false);
				new WesternFoodList();
			}
		});
		btnNewButton_3.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		btnNewButton_3.setBounds(590, 195, 150, 86);
		frmKategorie.getContentPane().add(btnNewButton_3);

		JButton btnNewButton_4 = new JButton("");
		btnNewButton_4.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\back.png"));
		btnNewButton_4.setBorderPainted(false);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmKategorie.setVisible(false);
				new Main();
			}
		});
		btnNewButton_4.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		btnNewButton_4.setBounds(12, 10, 140, 50);
		frmKategorie.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_3_1 = new JButton("");
		btnNewButton_3_1.setBorderPainted(false);
		btnNewButton_3_1.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\분식.png"));
		btnNewButton_3_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_3_1.setFocusPainted(false);
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmKategorie.setVisible(false);
				new SnackFoodList();
			}
		});
		btnNewButton_3_1.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		btnNewButton_3_1.setBounds(110, 335, 150, 86);
		frmKategorie.getContentPane().add(btnNewButton_3_1);
		
		JButton btnNewButton_3_2 = new JButton("");
		btnNewButton_3_2.setBorderPainted(false);
		btnNewButton_3_2.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\뷔페.png"));
		btnNewButton_3_2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_3_2.setFocusPainted(false);
		btnNewButton_3_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmKategorie.setVisible(false);
				new BuffetFoodList();
			}
		});
		btnNewButton_3_2.setFont(new Font("배달의민족 주아", Font.BOLD, 35));
		btnNewButton_3_2.setBounds(320, 335, 150, 86);
		frmKategorie.getContentPane().add(btnNewButton_3_2);
		
		JButton btnNewButton_3_3 = new JButton("");
		btnNewButton_3_3.setBorderPainted(false);
		btnNewButton_3_3.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\기타.png"));
		btnNewButton_3_3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_3_3.setFocusPainted(false);
		btnNewButton_3_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmKategorie.setVisible(false);
				new EtcFoodList();
			}
		});
		btnNewButton_3_3.setFont(new Font("배달의민족 주아", Font.BOLD, 40));
		btnNewButton_3_3.setBounds(530, 335, 150, 86);
		frmKategorie.getContentPane().add(btnNewButton_3_3);
	}
	
//	public static void main(String[] a) {
//		new Kategorie();
//	}
}
