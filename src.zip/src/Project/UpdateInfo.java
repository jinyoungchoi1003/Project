package Project;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;

import db.awt.MemberDAO;

public class UpdateInfo {

	private JFrame frmInfomation;
	private JPasswordField pwdField;
	private JPasswordField pwField;
	private JPasswordField checkpwdField;
	private MemberDAO dao;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					UpdateInfo window = new UpdateInfo();
//					window.frmInfomation.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public UpdateInfo() {
		initialize();
	}

	public JPasswordField getPwdField() {
		return pwdField;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		dao = new MemberDAO();
		frmInfomation = new JFrame();
		frmInfomation.setTitle("Infomation");
		frmInfomation.setBounds(100, 100, 800, 600);
		frmInfomation.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmInfomation.getContentPane().setLayout(null);
		frmInfomation.setLocationRelativeTo(null);
		frmInfomation.setResizable(false);

		JLabel updateInfoLabel = new JLabel("회원정보 수정");
		updateInfoLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 50));
		updateInfoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		updateInfoLabel.setBounds(237, 64, 302, 94);
		frmInfomation.getContentPane().add(updateInfoLabel);

		JLabel lblNewLabel = new JLabel("현재 비밀번호");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 30));
		lblNewLabel.setBounds(173, 186, 196, 38);
		frmInfomation.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("새 비밀번호");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("배달의민족 주아", Font.BOLD, 30));
		lblNewLabel_1.setBounds(173, 251, 196, 38);
		frmInfomation.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("새 비밀번호 확인");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setFont(new Font("배달의민족 주아", Font.BOLD, 30));
		lblNewLabel_1_1.setBounds(173, 317, 196, 38);
		frmInfomation.getContentPane().add(lblNewLabel_1_1);

		JButton btnNewButton = new JButton("변경");
		btnNewButton.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				boolean b = dao.pwCheck(pwdField.getText());
				if (pwdField.getText().equals("") && pwField.getText().equals("")
						&& checkpwdField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "현재 비밀번호 또는 새 비밀번호 및 새 비밀번호 확인을 입력해주세요.");
				} else if (pwdField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "현재 비밀번호를 입력해주세요.");
				} else if (pwField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "새 비밀번호를 입력해주세요.");
				} else if (checkpwdField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "새 비밀번호 확인을 입력해주세요.");
				} else if (b == false) {
					JOptionPane.showMessageDialog(null, "현재 비밀번호가 일치하지 않습니다.\n확인 후 다시 시도해주세요.");
				} else if (pwdField.getText().equals(pwField.getText())) {
					JOptionPane.showMessageDialog(null, "기존 비밀번호와 동일한 비밀번호를 입력하셨습니다.\n다시 입력해주세요.");
				} else if (!pwField.getText().equals(checkpwdField.getText())) {
					JOptionPane.showMessageDialog(null, "입력한 새 비밀번호가 서로 일치하지 않습니다.\n확인 후 다시 시도해주세요.");
				} else {
					dao.updateInfo(pwField.getText());
					JOptionPane.showMessageDialog(null, "비밀번호가 정상적으로 변경되었습니다.\n다시 로그인 해주세요.");
					frmInfomation.dispose();
					new Login();
				}
			}
		});
		btnNewButton.setFont(new Font("배달의민족 주아", Font.BOLD, 30));
		btnNewButton.setBounds(194, 398, 175, 81);
		frmInfomation.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("취소");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmInfomation.setVisible(false);
				new UserInfomation();
			}
		});
		btnNewButton_1.setFont(new Font("배달의민족 주아", Font.BOLD, 30));
		btnNewButton_1.setBounds(396, 398, 164, 81);
		frmInfomation.getContentPane().add(btnNewButton_1);
		// 현
		pwdField = new JPasswordField();
		pwdField.setBounds(381, 199, 179, 21);
		frmInfomation.getContentPane().add(pwdField);
		// 새
		pwField = new JPasswordField();
		pwField.setBounds(381, 264, 179, 21);
		frmInfomation.getContentPane().add(pwField);
		// 새 확
		checkpwdField = new JPasswordField();
		checkpwdField.setBounds(381, 330, 179, 21);
		frmInfomation.getContentPane().add(checkpwdField);

		frmInfomation.setVisible(true);
	}
}
