package Project;

public class MainPage {

	public static void main(String[] args) {
		new Login();
	}

}
