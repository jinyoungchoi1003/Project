package Project;

//import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Dimension;
import javax.swing.SwingConstants;

import db.awt.MemberDAO;
import db.awt.MemberVo;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JPasswordField;
import java.awt.Cursor;

public class SignUp {
	private JFrame frame;
	private JTextField nickname;
	private JTextField email;
	private JPasswordField pwdtxt;
	private JPasswordField checkpwdtxt;
	private MemberDAO dao;
	private JTextField idtxt;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					SignUp window = new SignUp();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public SignUp() {
		initialize();

	}

	public JFrame getFrame() {
		return frame;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		dao = new MemberDAO();
		frame = new JFrame("SignUp");
		frame.getContentPane().setFont(new Font("맑은 고딕", Font.BOLD, 12));
		frame.getContentPane().setBackground(Color.LIGHT_GRAY);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.getContentPane().setSize(new Dimension(400, 500));
		frame.setSize(new Dimension(586, 559));
		frame.setBounds(100, 100, 450, 559);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);

		JLabel lblNewLabel = new JLabel("아이디");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("배달의민족 주아", Font.BOLD, 15));
		lblNewLabel.setBounds(10, 275, 100, 20);
		frame.getContentPane().add(lblNewLabel);

		idtxt = new JTextField(30);
		idtxt.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		idtxt.setColumns(10);
		idtxt.setBounds(127, 278, 200, 20);
		frame.getContentPane().add(idtxt);

		JLabel lblNewLabel_1 = new JLabel("비밀번호");
		lblNewLabel_1.setFont(new Font("배달의민족 주아", Font.BOLD, 15));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 305, 100, 20);
		frame.getContentPane().add(lblNewLabel_1);

		nickname = new JTextField();
		nickname.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		nickname.setBounds(127, 368, 200, 20);
		frame.getContentPane().add(nickname);
		nickname.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("비밀번호 확인");
		lblNewLabel_2.setFont(new Font("배달의민족 주아", Font.BOLD, 15));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(10, 335, 100, 20);
		frame.getContentPane().add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("닉네임");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setFont(new Font("배달의민족 주아", Font.BOLD, 15));
		lblNewLabel_2_1.setBounds(10, 365, 100, 20);
		frame.getContentPane().add(lblNewLabel_2_1);

		JLabel lblNewLabel_3 = new JLabel("이메일");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("배달의민족 주아", Font.BOLD, 15));
		lblNewLabel_3.setBounds(10, 395, 100, 20);
		frame.getContentPane().add(lblNewLabel_3);

		email = new JTextField();
		email.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		email.setBounds(127, 398, 200, 20);
		frame.getContentPane().add(email);
		email.setColumns(10);

		JButton signupbtn = new JButton("회 원 가 입");
		signupbtn.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		signupbtn.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {

//				String idLength = idtxt.getText();
//				String pwLength = pwdtxt.getText();
//				String nickLength = nickname.getText();
//				String emailLength = email.getText();
//				if (idLength.length() > 29) {
//					JOptionPane.showMessageDialog(null, "아이디를 30자 이내로 입력해주세요.");
//				} else if (pwLength.length() > 29) {
//					JOptionPane.showMessageDialog(null, "비밀번호를 30자 이내로 입력해주세요.");
//				} else if (nickLength.length() > 29) {
//					JOptionPane.showMessageDialog(null, "닉네임을 30자 이내로 입력해주세요.");
//				} else if (emailLength.length() > 29) {
//					JOptionPane.showMessageDialog(null, "이메일을 30자 이내로 입력해주세요.");
//				} else 
				if (idtxt.getText().matches(".*[ +!@#$%^&*(),.?\\\":{}|<>=/_-]+.*")) {
					JOptionPane.showMessageDialog(null, "공백 또는 특수문자는 사용할 수 없습니다.");
				} else if (idtxt.getText().matches(".*[ㄱ-ㅎㅏ-ㅣ가-힣]+.*")) {
					JOptionPane.showMessageDialog(null, "영문 또는 숫자만 사용 가능합니다.");
				} else if (idtxt.getText().equals("") && (pwdtxt.getText().equals(""))
						&& (checkpwdtxt.getText().equals("")) && nickname.getText().equals("")
						&& email.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "입력하지 않은 빈 칸이 있습니다.");
				} else if (idtxt.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "아이디를 입력해주세요.");
				} else if (pwdtxt.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "비밀번호를 입력해주세요.");
				} else if (checkpwdtxt.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "비밀번호 확인을 입력해주세요.");
				} else if (nickname.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "닉네임을 입력해주세요.");
				} else if (email.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "이메일을 입력해주세요.");
				} else if (!pwdtxt.getText().equals(checkpwdtxt.getText())) {
					JOptionPane.showMessageDialog(null, "입력하신 비밀번호가 다릅니다.");
				} else {
					System.out.println(idtxt.getText());
					System.out.println(pwdtxt.getText());
					System.out.println(checkpwdtxt.getText());
					System.out.println(nickname.getText());
					System.out.println(email.getText());

					MemberVo vo = new MemberVo(idtxt.getText(), pwdtxt.getText(), nickname.getText(), email.getText());
					@SuppressWarnings("unused")
					boolean b = dao.SignUp(vo);
					JOptionPane.showMessageDialog(null, "회원가입이 완료되었습니다.");
					frame.setVisible(false);
//					new Login().getFrmLogin().setVisible(true);
					new Login();
				}
			}
		});
		signupbtn.setBounds(45, 425, 350, 87);
		frame.getContentPane().add(signupbtn);
		signupbtn.setEnabled(false);

		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setFont(new Font("맑은고딕", Font.BOLD, 15));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\Background.png"));
		lblNewLabel_6.setBounds(10, 70, 419, 195);
		frame.getContentPane().add(lblNewLabel_6);

		JButton backbtn = new JButton("");
		backbtn.setBorderPainted(false);
		backbtn.setBorder(null);
		backbtn.setFocusPainted(false);
		backbtn.setBackground(Color.LIGHT_GRAY);
		backbtn.setIcon(new ImageIcon("C:\\Users\\SAMSUNG\\Desktop\\프로젝트\\이미지\\새 폴더\\go_back_btn.png"));
		backbtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
//				MainPage.login().getFrmLogin().setVisible(true);
//				new Login().getFrmLogin().setVisible(true);
				new Login();
			}
		});
		backbtn.setFont(new Font("배달의민족 주아", Font.BOLD, 20));
		backbtn.setBounds(12, 10, 140, 50);
		frame.getContentPane().add(backbtn);

		pwdtxt = new JPasswordField();
		pwdtxt.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		pwdtxt.setBounds(127, 308, 200, 21);
		frame.getContentPane().add(pwdtxt);

		checkpwdtxt = new JPasswordField();
		checkpwdtxt.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		checkpwdtxt.setBounds(127, 338, 200, 21);
		frame.getContentPane().add(checkpwdtxt);

		JButton userIDCheck = new JButton("중복체크");
		userIDCheck.setFont(new Font("배달의민족 주아", Font.BOLD, 12));
		userIDCheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				boolean idCheck = new MemberDAO().IDCheck(idtxt.getText());

				if (idtxt.getText().matches(".*[ +!@#$%^&*(),.?\":{}|<>=/_-]+.*")) {
					JOptionPane.showMessageDialog(null, "공백 또는 특수문자는 사용할 수 없습니다.");
				} else if (idtxt.getText().matches(".*[ㄱ-ㅎㅏ-ㅣ가-힣]+.*")) {
					JOptionPane.showMessageDialog(null, "영문 또는 숫자만 사용 가능합니다.");
				} else if (idtxt.getText().length() > 30) {
					JOptionPane.showMessageDialog(null, "30자 이내로 입력해주세요.");
				} else if (idtxt.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "아이디를 입력해주세요.");
				} else if (idCheck == false) {
					JOptionPane.showMessageDialog(null, idtxt.getText() + " 는 사용 가능합니다.");
				} else {
					JOptionPane.showMessageDialog(null, "중복된 아이디 입니다.");
				}
			}
		});
		userIDCheck.setBounds(333, 277, 90, 23);
		frame.getContentPane().add(userIDCheck);

		JButton nickCheck = new JButton("중복체크");
		nickCheck.setFont(new Font("배달의민족 주아", Font.BOLD, 12));
		nickCheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean nickCheck = new MemberDAO().NickCheck(nickname.getText());

				if (nickname.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "닉네임을 입력해주세요.");
				} else if (nickCheck == false) {
					JOptionPane.showMessageDialog(null, nickname.getText() + " 는 사용 가능합니다.");
					signupbtn.setEnabled(true);
				} else {
					JOptionPane.showMessageDialog(null, "중복된 닉네임 입니다.");
				}
			}
		});
		nickCheck.setBounds(333, 368, 91, 20);
		frame.getContentPane().add(nickCheck);
	}
}
