package api;

public class FoodVO{
	private String company;
	private String foodType;
	private String city;
	private String address;
	private String phoneNumber;
	private String mainMemu;

	public FoodVO() {

	}

	public FoodVO(String company, String foodType, String city, String address, String phoneNumber, String mainMemu) {
		this.company = company;
		this.foodType = foodType;
		this.city = city;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.mainMemu = mainMemu;
	}

	public FoodVO(String company) {
		this.company = company;
	}

	public String getCompany() {
		return company;
	}

	public String getFoodType() {
		return foodType;
	}

	public String getCity() {
		return city;
	}

	public String getAddress() {
		return address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getMainMemu() {
		return mainMemu;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setMainMemu(String mainMemu) {
		this.mainMemu = mainMemu;
	}

}
