import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class JCheckBoxExmaple extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JFrame frame;
	private JButton btn;
	private JCheckBox checkbox;

	public JCheckBoxExmaple() {
		frame = new JFrame("Test");
		frame.setLayout(null);
		frame.setSize(800, 600);
		frame.setVisible(true);

		btn = new JButton("Click");
		btn.setBounds(100, 100, 100, 100);
		frame.add(btn);

		btn.addActionListener(this);

//		checkbox.setVisible(false);

	}

	int count = 0;

	@Override
	public void actionPerformed(ActionEvent e) {

		if (count >= 5) {
			JOptionPane.showMessageDialog(null, "멈춰");
		} else {
			checkbox = new JCheckBox("Java");
			checkbox.setBounds(200, 100 + count * 20, 100, 20);
			checkbox.setVisible(true);
			count++;
			frame.add(checkbox);
		}

	}

	public static void main(String[] args) {
		new JCheckBoxExmaple();
	}

}
